//Sum and Print 1-5

for(var num = 1, sum = 0; num <= 5; num++){
    console.log(num);
    sum=num+sum;
    console.log(sum);
    }