from django.db import models

# Create your models here.
from django.db import models
import re, bcrypt

# Create your models here.
class UserManager(models.Manager):
    def register_validator(self, postData):
        errors = {}
        users = User.objects.filter(email=postData["email"])
        if users:
            errors["existing_user"] = "An account was already made with the email address that was provided. Please enter a different email address."
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData["email"]): # test whether a field matches the pattern            
            errors['email'] = ("Invalid email address!")
        if len(postData["first_name"]) < 2:
            errors["first_name"] = "The field for 'First Name' must have at least two characters in it. Please correct."
        if len(postData["last_name"]) < 2:
            errors["last_name"] = "The field for 'Last Name' must have at least two characters in it. Please correct."
        if len(postData["password"]) < 8:
            errors["password"] = "Your password requires at least eight characters. Please check what you entered and reattempt."
        if postData["password"] != postData["confirm_password"]:
            errors["confirm_password"] = "The password you provided for 'password' does not match what you entered for 'confirm password.' Please check what you entered and reattempt."
        return errors
    def login_validator(self, postData):
        errors = {}
        existing_user = User.objects.filter(email=postData["email"])
        if len(existing_user) != 1:
            errors["email"] = "Currently, there is no email address with that account information."
        if len(postData["email"]) == 0:
            errors["email"] = "Please do not forget to provide your email address."
        if len(postData["password"]) < 8:
            errors["password"] = "Your password requires at least eight characters. Please check what you entered and reattempt."
        if postData["password"] != postData["confirm_password"]:
            errors["confirm_password"] = "The password you provided for 'password' does not match what you entered for 'confirm password.' Please check what you entered and reattempt."
        return errors

class User(models.Model):                                                       #might need to edit
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=75)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

class WishManager(models.Manager):
    def wish_validator(self, postData):
        errors = {}
        if len(postData["title"]) < 1:
            errors["title"] = "The title field cannot be left blank. Please enter the title of the book you would like to add."
        if len(postData["description"])< 5:
            errors["description"] = "A description is mandatory and must be at least 5 characters long."
        return errors


class Wish(models.Model):
    item = models.CharField(max_length = 75)                                #title becomes item
    description = models.TextField(default = "There is currently no description entered.")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    granted_on = models.DateTimeField(auto_now=True)                        #new, added
    description = models.TextField(default = "There is currently no description entered.")
    user_that_has = models.ForeignKey(User, related_name="wishes_uploaded", on_delete = models.CASCADE) # changed "book uplaoded" to "wish_uploaded"
    users_that_granted = models.ManyToManyField(User, related_name="wishes_granted")
    # users_that_liked_granted = models.ManyToManyField(User, related_name="wishes_liked_granted")
    objects = WishManager()