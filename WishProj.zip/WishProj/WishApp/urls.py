from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('', views.log_and_reg),                    #path to login and registration         localhost:8000/
    path('create_user', views.create_user),            #path to create a new user              localhost:8000/register              
    path('login', views.login),                     #path for existing user to login        localhost:8000/login
    path('logout', views.logout),                   #path for existing user to logout       localhost:8000/logout
    path('formRequest', views.toCreateForm),                   #will redirect to generate wish form    localhost:8000/toCreateForm
    path('create', views.create),                   #will redirect to generate wish form    localhost:8000/toCreateForm
    path('dashboard', views.dashboard),
    path('wishes/<int:wish_id>', views.wish_profile),
    path('wishes/<int:wish_id>/update', views.update),
    path('granted/<int:wish_id>', views.granted),