from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import User, Wish
import bcrypt

def log_and_reg(request):
    return render(request, "index.html")

def create_user(request):
    errors = User.objects.register_validator(request.POST)
    if errors:
            for key, val in errors.items():
                messages.error(request, val)
            return redirect("/")
    else:
        password = request.POST["password"] #retrieving password from POST dictionary, still plain text
        hash_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode() #next, hashing and salting! ...remember, we need to decode before putting into database.
        user = User.objects.create(
            first_name=request.POST["first_name"],
            last_name=request.POST["last_name"],
            email=request.POST["email"],
            password=hash_pw,
        )
        request.session["userid"] = user.id
        request.session["greeting"] = user.first_name
        messages.success(request, "Congrats! Wishes galore are bound to be yours!")
        return redirect("/dashboard")                                                           

def login(request):
    users = User.objects.filter(email = request.POST["email"])
    if users:
        logged_user = users[0]
        if bcrypt.checkpw(request.POST["password"].encode(), logged_user.password.encode()):
            request.session["userid"] = logged_user.id
            messages.success(request, "...Guess what? You're logged in!")
            return redirect("/dashboard")                                                      
        else:
            messages.error(request, "Your email and password did not match. Please try again.")
    else:
        messages.error(request, "The email address that you entered has never been registered for an account.")
    return redirect("/dashboard")                                                            

def toCreateForm(request):
    return render(request, 'create.html')

def create(request):
    errors = Wish.objects.wish_validator(request.POST)
    if len(errors):
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/dashboard")
    else:
        user = User.objects.get(id=request.session["userid"])
        wish = Wish.objects.create(
            item = request.POST["item"],
            description = request.POST["description"],
            user_that_has = user
        )
        return redirect("/dashboard")
        return redirect(f"/wishes/{wish.id}")


def dashboard(request):
    if "userid" not in request.session:
        return redirect("/")
    else:
        context = {
            "all_wishes": Wish.objects.all(),
            "current_user": User.objects.get(id=request.session["userid"])
        }
        return render(request, "dashboard.html", context)

def formUpdate(request):
    return render(request, "update.html")

def update(request, wish_id):
    wish = Wish.objects.get(id=wish_id)
    wish.description = request.POST["description"]
    wish.save()
    return redirect("/dashboard")

def logout(request):
    request.session.flush()
    return redirect("/")


def wish_profile(request, wish_id):
    context = {
        "wish": Wish.objects.get(id=wish_id),
        "current_user": User.objects.get(id=request.session["userid"])
    }
    return render(request, "update.html", context)

def granted(request, wish_id):
    user = User.objects.get(id=request.session["userid"])
    wish = Wish.objects.get(id=wish_id)
    user.wishes_granted.add(wish)

    return redirect('/dashboard')

def destroy(request, wish_id):
    wish = Wish.objects.get(id=wish_id)
    wish.delete()
    return redirect('/dashboard')