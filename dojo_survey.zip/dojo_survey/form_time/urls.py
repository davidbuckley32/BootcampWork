from django.urls import path
from . import views
urlpatterns = [
    path('', views.obtaining_form_data),
    path('process', views.process), # why is this needed?
]