from django.shortcuts import render, redirect #Why HttpResponse not needed?
def obtaining_form_data(request):
        # request.method == "POST"
        # print(request.POST)
    return render(request, "form.html")
def process(request):
    if request.method == "POST": #why loop needed if SURE will be POST?
        context = {
            'your_name': request.POST['your_name'],
            'dojo_location': request.POST['dojo_location'],
            'favorite_language': request.POST['favorite_language'],
            'comment': request.POST['comment'],
        }
        return render(request, 'result.html', context)
    return render(request, 'result.html')