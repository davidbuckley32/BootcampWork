from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('', views.index),
    path('register', views.register),
    path('login', views.login),
    path('profile', views.profile),
    path('create', views.create),
    path('books/<int:book_id>', views.book_profile),
]
