from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import User, Book
import bcrypt

def index(request):
    request.session.flush()
    return render(request, "index.html")

def register(request):
    errors = User.objects.register_validator(request.POST)
    if errors:
            for key, val in errors.items():
                messages.error(request, val)
            return redirect("/")
    else:
        password = request.POST["password"] #retrieving password from POST dictionary, still plain text
        hash_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode() #next, hashing and salting! ...remember, we need to decode before putting into database.
        user = User.objects.create(
            first_name=request.POST["first_name"],
            last_name=request.POST["last_name"],
            email=request.POST["email"],
            password=hash_pw,
        )
        request.session["userid"] = user.id
        request.session["greeting"] = user.first_name
        messages.success(request, "Congrats! You successfully registered your account!")
        return redirect("/books") #remember to include this redirect
        return redirect("/profile") #remember to include this redirect
    return redirect("/books")

def login(request):
    users = User.objects.filter(email = request.POST["email"])
    if users:
        logged_user = users[0]
        if bcrypt.checkpw(request.POST["password"].encode(), logged_user.password.encode()):
            request.session["userid"] = logged_user.id
            messages.success(request, "...Guess what? You're logged in!")
            return redirect("/books")
            # return redirect("/books")
        else:
            messages.error(request, "Your email and password did not match. Please try again.")
    else:
        messages.error(request, "The email address that you entered has never been registered for an account.")
    return redirect("/books")

# def profile(request):
#     context = {
#         "user" : User.objects.get(id=request.session["userid"])
#     }
#     return render(request, "profile.html", context)

def create(request):
    errors = Book.objects.book_validator(request.POST)
    if len(errors):
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/books")
    else:
        user = User.objects.get(id=request.session["userid"])
        book = Book.objects.create(
            title = request.POST["title"],
            description = request.POST["description"],
            user_that_has = user
            # creator = user
        )
        return redirect(f"/books/{book.id}")

def book_profile(request, book_id):
    context = {
        "book": Book.objects.get(id=book_id),
        "current_user": User.objects.get(id=request.session["userid"])
    }
    return render(request, "book_profile.html", context)

def books_all(request):
    if "userid" not in request.session:
        return redirect('/')
    else:
        context = {
            "all_books": Book.objects.all(),
            "current_user": User.objects.get(id=request.session["userid"])
        }
        return render(request, "books_all.html", context)

def favorite(request, book_id):
    user = User.objects.get(id=request.session["userid"])
    book = Book.objects.get(id=book_id)
    user.books_favorited.add(book)

    return redirect(f'/books/{book_id}')

def unfavorite(request, book_id):
    user = User.objects.get(id=request.session["userid"])
    book = Book.objects.get(id=book_id)
    user.books_favorited.remove(book)

    return redirect(f'/books/{book_id}')

def update(request, book_id):
    book = Book.objects.get(id=book_id)
    book.description = request.POST["description"]
    book.save()
    return redirect("/books")

def delete(request, book_id):
    book = Book.objects.get(id=book_id)
    book.delete()
    return redirect('/books')

def logout(request):
    request.session.flush()
    return redirect('/')