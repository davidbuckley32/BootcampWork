from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import User
import bcrypt

def index(request):
    request.session.flush()
    return render(request, "index.html")

def register(request):
    errors = User.objects.register_validator(request.POST)
    if errors:
            for key, val in errors.items():
                messages.error(request, val)
    else:
        password = request.POST["password"] #retrieving password from POST dictionary, still plain text
        hash_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode() #next, hashing and salting! ...remember, we need to decode before putting into database.
        user = User.objects.create(
            first_name=request.POST["first_name"],
            last_name=request.POST["last_name"],
            email=request.POST["email"],
            password=hash_pw,
        )
        request.session['userid'] = user.id
        messages.success(request, "Congrats! You successfully registered your account!")
        return redirect("/profile") #remember to include this redirect
    return redirect("/")

def login(request):
    users = User.objects.filter(email = request.POST["email"])
    if users:
        logged_user = users[0]
        if bcrypt.checkpw(request.POST["password"].encode(), logged_user.password.encode()):
            request.session['userid'] = logged_user.id
            messages.success(request, "...Guess what? You're logged in!")
            return redirect("/profile")
        else:
            messages.error(request, "Your email and password did not match. Please try again.")
    else:
        messages.error(request, "The email address that you entered has never been registered for an account.")
    return redirect("/")

def profile(request):
    context = {
        "user" : User.objects.get(id=request.session['userid'])
    }
    return render(request, "profile.html", context)

def create(request):
    pass