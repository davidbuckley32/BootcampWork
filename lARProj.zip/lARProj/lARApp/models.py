from django.db import models
import re
import bcrypt

class UserManager(models.Manager):
    def register_validator(self, postData): #one validator for each form
        errors = {}                         #remember to begin the dictionary
        users = User.objects.filter(email=postData["email"])
        if users:
            errors['existing_user'] = "An account was already made with the email address that was provided. Please enter a different email address."
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']): # test whether a field matches the pattern            
            errors['email'] = ("Invalid email address!")
        if len(postData["first_name"]) < 2:
            errors["first_name"] = "The first name entry input requires at least two characters. Please check what you entered and reattempt."
        if len(postData["last_name"]) < 2:
            errors["last_name"] = "The last name entry input requires at least two characters. Please check what you entered and reattempt."
        if len(postData["first_name"]) < 2:
            errors["first_name"] = "The first name entry input requires at least two characters. Please check what you entered and reattempt."
        if len(postData["password"]) < 8:
            errors["password"] = "Your password requires at least eight characters. Please check what you entered and reattempt."
        if postData["password"] != postData["confirm_password"]:
            errors["confirm_password"] = "The password you input for 'password' does not match what you entered for 'confirm password.' Please check what you entered and reattempt."
        return errors
    def login_validator(self, postData):    #one validator for each form
        errors = {}
        existing_user = User.objects.filter(email=postData["email"])
        if len(existing_user) != 1:
            errors['email'] = "Currently, there is no email address with that account information."
        if len(postData["email"]) == 0:
            errors['email'] = "Please do not forget to provide your email address."
        if len(postData["password"]) < 8:
            errors["password"] = "Your password requires at least eight characters. Please check what you entered and reattempt."
        if postData["password"] != postData["confirm_password"]:
            errors["confirm_password"] = "The password you input for 'password' does not match what you entered for 'confirm password.' Please check what you entered and reattempt."
        return errors

class User(models.Model):
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    email = models.EmailField(unique=True) #check this
    password = models.CharField(max_length=255)
    objects = UserManager()         #once want to validate, remember this!