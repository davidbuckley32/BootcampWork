from django.urls import path
from . import views

urlpatterns = [
    path('', views.log_and_reg), #localhost:8000/                   shows form
    path('register', views.register), #localhost:8000/register     hooked up to register form
    path('index', views.index), #localhost:8000/index              hooked up to generate homepage after login
    path('login', views.login), #localhost:8000/login              hooked up to login form
    path('logout', views.logout), #localhost:8000/logout           hooked up to logout button
]