from django.http.response import HttpResponse
from django.shortcuts import render, HttpResponse, redirect

def create_form(request):
    # return redirect(request, 'create_form.html')
    return render(request, 'create_form.html')