from django.http.response import HttpResponse
from django.shortcuts import render, HttpResponse, redirect

def index(request):
    # return redirect(request, 'create_form.html')
    return render(request, 'index.html')

def create(request): #creating a dictionary for my values from the form to be stored
    context = {
        'name': request.POST['your_name'],    #whenever getting a value, need to use post
        'location': request.POST['your_location'],
        'language': request.POST['your_language'],
    }
    return render(request, 'display_user.html', context)   #to see information... html needs to receive context
    