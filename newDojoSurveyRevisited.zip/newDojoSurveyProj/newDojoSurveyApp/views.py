from django.http.response import HttpResponse
from django.shortcuts import render, HttpResponse, redirect

def index(request):
    # return redirect(request, 'create_form.html')
    return render(request, 'index.html')

def create(request): #creating a dictionary for my values from the form to be stored
    request.session['name'] = request.POST['your_name']
    request.session['location'] = request.POST['dojo_location']
    request.session['language'] = request.POST['your_language']
    
    return redirect('/display_dashboard')   #to see information... html needs to receive context, changed "render" to "redirect" here to prevent resubmission issues

def dashboard(request):
    # context = { #only lives on a render, see below
    #     'name': request.session['name'],    #whenever getting a value, need to use post
    #     'location': request.session['location'],
    #     'language': request.session['language']
    # }
    return render(request, 'display_user.html')

    