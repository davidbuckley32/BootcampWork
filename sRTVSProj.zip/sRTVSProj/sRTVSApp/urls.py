# from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('programs', views.index),                              #localhost:8000/programs
    path('programs/new', views.new),                            #localhost:8000/programs/new
    # path('programs/create', views.create),                      localhost:8000/programs/create
    path('programs/<int:program_id>', views.show),               #localhost:8000/program/<int:program_id>
    path('programs/<int:program_id>/edit', views.edit),         #locathost:8000/program/<int:program_id>/edit
    path('programs/<int:program_id>/update', views.update),     #localhost:8000/program/<int:program_id>/update
    path('programs/<int:program_id>/destroy', views.destroy),   #localhost:8000/program/<int:program_id>/destroy
    # path('admin/', admin.site.urls),
]