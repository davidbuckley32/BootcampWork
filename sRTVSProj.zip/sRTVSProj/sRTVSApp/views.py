from django.shortcuts import render

def index(request):
    pass