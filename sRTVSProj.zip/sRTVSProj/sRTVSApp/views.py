from django.shortcuts import render, redirect

def index(request):
    return render(request, 'index.html')

def new(request):
    pass

def create(request):
    pass

def show(request):
    pass

def edit(request):
    pass

def update(request):
    pass

def destroy(request):
    pass