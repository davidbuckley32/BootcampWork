from django.shortcuts import render, redirect
from .models import Program

def index(request):
    return render(request, 'index.html')

def new(request):
    return render(request, 'new.html')

# def create(request): 
#     progam1 = Program.objects.create( the first instance of the class will be input by the user here
#         title = request.POST['title'],
#         network = request.POST['network'],
#         description = request.POST['description'],
#         release_date = request.POST['release'],
#     )
#     return redirect('/<int:program_id>')

def show(request, program_id):
    return render(request, 'program.html')

def edit(request, program_id):
    return render(request, 'edit.html')

def update(request):
    pass

def destroy(request):
    pass