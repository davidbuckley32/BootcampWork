from django.db import models

class ProgramManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        if len(postData['title']) <= 0:
            errors["title"] = "You left TITLE blank. Please complete the field."
        if len(postData['network']) <= 0:
            errors["network"] = "You left NETWORK blank. Please complete the field."
        if len(postData['description']) <= 0:
            errors["description"] = "You left DESCRIPTION blank. Please complete the field."
        return errors

class Program(models.Model):
    title = models.CharField(max_length=45)
    network = models.CharField(max_length=45)
    description = models.TextField()
    release_date = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = ProgramManager()