from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Program

def index(request):                             #accessing data from form, so context is needed
    context = {
        'programs': Program.objects.all()       #will be using this later in forloop to display information in table
    }
    return render(request, 'index.html', context)        #this line was one of two first written out, but moving down

def new(request):
    return render(request, 'new.html') 

def create(request):
    errors = Program.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/programs/new')
    Program.objects.create(                 #1. adding validation above this
        title = request.POST['title'],
        network = request.POST['network'],
        description = request.POST['description'],
        release_date = request.POST['date'],
    )
    return redirect('/programs')
    # return redirect('/<int:program_id>')


# def create(request): before editing for validation
    # Program.objects.create( #the first instance of the class will be input by the user here
    #     title = request.POST['title'],
    #     network = request.POST['network'],
    #     description = request.POST['description'],
    #     release_date = request.POST['date'],
    # )
    # return redirect('/programs')


# def create(request): Will's Way
#     program1 = Program.objects.create( #the first instance of the class will be input by the user here
#         title = request.POST['title'],
#         network = request.POST['network'],
#         description = request.POST['description'],
#         release_date = request.POST['release'],
#     )
#     return redirect('/<int:program_id>')

def show(request, program_id):
    one_program = Program.objects.get(id=program_id)
    context = {
        'program': one_program
    }
    return render(request, 'program.html', context)

def edit(request, program_id):
    one_program = Program.objects.get(id=program_id)
    context = {
        'program': one_program
    }
    return render(request, 'edit.html', context)

def update(request, program_id):
    errors = Program.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f'/programs/{program_id}/edit')
    to_update = Program.objects.get(id=program_id)          # 1. validation edits go above
    to_update.title = request.POST['title']
    to_update.network = request.POST['network']
    to_update.description = request.POST['description']
    to_update.release_date = request.POST['date']
    to_update.save()

    return redirect('/programs')

# def update(request, program_id):                            before validation
#     to_update = Program.objects.get(id=program_id)
#     to_update.title = request.POST['title']
#     to_update.network = request.POST['network']
#     to_update.description = request.POST['description']
#     to_update.release_date = request.POST['date']
#     to_update.save()

#     return redirect('/programs')

def destroy(request, program_id):
    to_delete = Program.objects.get(id=program_id)
    to_delete.delete()
    return redirect('/programs')