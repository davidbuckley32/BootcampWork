from django.apps import AppConfig


class SecondtimedisplayappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'secondTimeDisplayApp'
